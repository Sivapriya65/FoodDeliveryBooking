package FoodDeliverBooking;

import java.util.Scanner;

class fooddeliver {
	public static void main(String args[]) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Number of Customers");
		int user = input.nextInt();// Get value from user
		for (int i = 1; i <= user; i++) {
			deliver dlr = new deliver();
			dlr.Booking();// Function to handle Booking
			dlr.DeliveryExecutive();// Function to assign delivery executives
			dlr.DeEarnActivity();// Functions that can display delivery executive's activity
			System.out.println("--------------------------------------------------------------");
		}
		
		System.out.println("Process Finished");

	}
}

interface functions {
	public void Booking();

	public void DeliveryExecutive();

	public void DeEarnActivity();

}

class deliver implements functions {
	public void Booking() {
		// TODO Auto-generated method stub
		Scanner Book = new Scanner(System.in);
		System.out.println("Customer ID: ");
		int id = Book.nextInt();
		System.out.println("\nChoose Restaurant: \nA\nB\nC\nD\nE ");
		String Rest = Book.next();

		System.out.println("\nDestination Point: ");
		String Dest = Book.next();

		System.out.println("\nTime: ");
		String Time = Book.next();

		System.out.println("\nBooking id " + id);

	}

	public void DeliveryExecutive() {
		// TODO Auto-generated method stub
		Scanner Dex = new Scanner(System.in);
		int delivery = 0;

		System.out.println("Enter Orders");// Gets orders
		int ord = Dex.nextInt();

		System.out.println("executive is");// Assign executive
		int ex = Dex.nextInt();

		System.out.println("Available Executives:");

		System.out.println("alloted executive is:" + ex);
		int Allowance = 10;// Allowance charge for each executive is Rs.10

		if (ord <= 5) // maximum of 5 per delivery executives
		{

			delivery = 50 + 5 * (ord - 1);// Delivery charge for each executive is Rs.50 for the delivery executive

		}

		System.out.println("Executed by DE" + ex);

		int Earned = 0;
		System.out.println("---------------------------------------------------------------");
		System.out.println("Executive \t   Delivery charge \t    Earned");

		System.out.println("DE" + ex + "\t\t\t" + delivery + "\t\t\t" + Earned);// Display delivery charge of each
																				// executives
		System.out.println("---------------------------------------------------------------");

		System.out.println("Total earned");
		Earned = Allowance + delivery;// Sum delivery with Allowance charge
		System.out.println("---------------------------------------------------------------");
		System.out.println("Executive \t    Allowance \t    Delivery charge \t    Earned");

		System.out.println("DE" + ex + "\t\t\t" + Allowance + "\t\t\t" + delivery + "\t\t" + Earned);
		System.out.println("---------------------------------------------------------------");

	}

	public void DeEarnActivity() {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int matrix[][] = new int[50][50];
		System.out.println("Total Number of Executives");
		int ex = input.nextInt();

		System.out.println("Executives\tDeliverycharge\tEarned");
		System.out.println();

		for (int rownum = 1; rownum <= ex; rownum++) {
			System.out.print("DE" + (rownum) + "\t");
			for (int col = 1; col <= 2; col++) {
				matrix[rownum][col] = 0;
				System.out.print(matrix[rownum][col] + "\t\t");
			}
			System.out.println();
		}

		for (int i = 1; i <= 2; i++) {

			System.out.println("Enter row and column seperated by space selected upon executive"); // Enter two values to
																								// calculate Earning of
																								// delivery executive
			int x = input.nextInt();
			int y = input.nextInt();
			
			System.out.println("Order ");
			int ord = input.nextInt();

			if (x > 0 && y > 0) {
				System.out.println("Allocate executive");
				System.out.println();
			}
			
			

			System.out.println("-------------------------------------------");
			System.out.println("Executives\tDeliverycharge\tEarned");
			System.out.println("-------------------------------------------");
			

			for (int rownum = 1; rownum <= ex; rownum++)//To calculate the value of selected 
			{
				System.out.print("\nDE" + (rownum) + "\t\t\t");

				for (int col = 1; col <= 2; col++) {
					if (y == 1 && y != 2) {

						matrix[x][y] = (50 + 5 * (ord - 1));// Delivery Charge

					}

					if (y == 2 && y != 1) {
						matrix[x][y] = (50 + 5 * (ord - 1)) + 10;// Allowance + Delivery

					}

					System.out.print(matrix[rownum][col] + "\t\t");

				}

			}
			System.out.println();
		}

	}

}
